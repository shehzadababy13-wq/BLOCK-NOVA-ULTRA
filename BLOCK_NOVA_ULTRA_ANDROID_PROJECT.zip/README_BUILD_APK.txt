BLOCK NOVA ULTRA — Android APK build starter

This folder wraps your HTML game with Capacitor for Android.

BUILD REQUIREMENTS (on a Windows/Mac/Linux computer):
1. Install Node.js LTS: https://nodejs.org
2. Install Android Studio: https://developer.android.com/studio
3. Extract this ZIP.
4. Open a terminal in this folder and run:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
5. In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
6. APK is normally at: android/app/build/outputs/apk/debug/app-debug.apk

For Google Play upload, create a signed release AAB in Android Studio instead.

IMPORTANT:
- The HTML game files are bundled locally (offline-capable; internet not needed to launch).
- Package ID: com.blocknova.ultra
- App name: BLOCK NOVA ULTRA
- This ZIP is a project starter, NOT a compiled APK. Android SDK/Gradle build is required to compile APK.

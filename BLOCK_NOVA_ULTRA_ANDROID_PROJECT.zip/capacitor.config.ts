import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.blocknova.ultra',
  appName: 'BLOCK NOVA ULTRA',
  webDir: 'www',
  bundledWebRuntime: false
};
export default config;

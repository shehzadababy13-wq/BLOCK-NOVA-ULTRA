BLOCK NOVA ULTRA

Files:
- index.html: complete browser-playable game
- app_icon.png: 1024x1024 master app icon
- favicon.png: browser favicon
- icons/: PWA icon sizes
- manifest.webmanifest: installable web app metadata
- sw.js: offline cache service worker

How to play:
- Tap a block piece in the tray to rotate it.
- Drag a piece onto the 10x10 board to place it.
- Complete rows/columns to clear them and score.
- Power-ups are available at the bottom of the game.

To test: extract the ZIP and open index.html in a modern browser.
Note: Service-worker/offline install features require hosting over HTTPS (or localhost).
